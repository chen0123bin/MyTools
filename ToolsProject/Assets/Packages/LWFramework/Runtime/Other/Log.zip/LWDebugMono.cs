﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System;

public enum LogColor
{
    red, yellow, blue, green, cyan, grey, white, _default
}
public class LWDebug {  
    public static void Log(object info, LogColor color=LogColor._default)
    {
        if (LWDebugMono.GetInstance().IsSelectLogType(LogType.Log)) {
            Debug.Log(string.Format(GetHexByColor(color), info));
        }      
    }

    public static void LogError(object info)
    {
        if (LWDebugMono.GetInstance().IsSelectLogType(LogType.Error))
            Debug.LogError(info);
    }
    public static void LogWarning(object info)
    {
        if (LWDebugMono.GetInstance().IsSelectLogType(LogType.Warning))
            Debug.LogWarning(info);
    }

    
    static string GetHexByColor(LogColor color) {
#if UNITY_EDITOR
        string defaultHex = "<color=#000000ff>{0}</color>";
        switch (color)
        {
            case LogColor.red:
                defaultHex = "<color=#ff0000>{0}</color>";
                break;
            case LogColor.yellow:
                defaultHex = "<color=#ffff00ff>{0}</color>";
                break;
            case LogColor.blue:
                defaultHex = "<color=#0000ffff>{0}</color>";
                break;
            case LogColor.green:
                defaultHex = "<color=#008000ff>{0}</color>";
                break;
            case LogColor.cyan:
                defaultHex = "<color=#00ffffff>{0}</color>";
                break;
            case LogColor.grey:
                defaultHex = "<color=#808080ff>{0}</color>";
                break;
            case LogColor.white:
                defaultHex = "<color=#ffffffff>{0}</color>";
                break;
            case LogColor._default:

                defaultHex = "<color=#33CCCC>{0}</color>";
                break;
            default:
                break;
        }

#else
 string defaultHex = "{0}";
#endif
        return defaultHex;
    }
}
[DefaultExecutionOrder(-1000)]
public class LWDebugMono : MonoBehaviour
{
    protected static LWDebugMono instance = null;

    public static LWDebugMono GetInstance()
    {
        if (instance == null)
        {
            instance = FindObjectOfType<LWDebugMono>();
            if (instance == null)
            {
                GameObject go = new GameObject();
                go.name = typeof(LWDebugMono).Name;
                instance = go.AddComponent<LWDebugMono>();
            }
        }

        return instance;
    }

    //文件的路径
    private string path;
    public bool netlog = true;
    public string serverIp = "192.168.1.1";
    public int logLevel = 3;

    string FileName {
        get {          
            return "logInfo" + DateTime.Now.ToString("yyyyMMddHH") + ".txt";
        }
    }
    void OnEnable()
    {
        skin = Resources.Load<GUISkin>("LogGUISkin");
        curLog = m_logAll;
        Application.logMessageReceivedThreaded += OnLogMessageReceivedThreaded;
        if (netlog) {
            LWLogClient.GetSingleton().Connect(serverIp, 12312);
        }
    }
    void OnDisable()
    {
       // Application.logMessageReceivedThreaded -= OnLogMessageReceivedThreaded;
    }

    private void OnLogMessageReceivedThreaded(string condition, string stackTrace, LogType type)
    {
        LogInfo logInfo = new LogInfo(type, condition, stackTrace, DateTime.Now.ToString("yyyy年MM月dd日 HH:mm:ss"));
        switch (type)
        {
            case LogType.Warning:
                m_logWarning.Add(logInfo);
                break;
            case LogType.Log:
                m_logLog.Add(logInfo);
                break;
            case LogType.Error:
            case LogType.Exception:
                m_logError.Add(logInfo);
                break;
        }
        m_logAll.Add(logInfo);

       
        if (path == null) {
#if !UNITY_EDITOR
        path = Application.persistentDataPath + "/";
        FileTool.WriteToFile(FileName, logInfo.ToString(), path);
        if(netlog)
            LWLogClient.GetSingleton().Send(type + System.Environment.NewLine + condition + System.Environment.NewLine + stackTrace);
#endif
        }

    }

    //判断是否选择了该枚举值
    public bool IsSelectLogType(LogType _logType)
    {

        if ((int)_logType <= logLevel)
        {
            return true;
        }
        else {
            return false;
        }

       
    }  
    //错误详情
    public List<LogInfo> m_logAll = new List<LogInfo>();
    public List<LogInfo> m_logLog = new List<LogInfo>();
    public List<LogInfo> m_logWarning = new List<LogInfo>();
    public List<LogInfo> m_logError = new List<LogInfo>();
    public List<LogInfo> curLog = new List<LogInfo>();
    //是否显示错误窗口
    private bool m_IsVisible = false;
    //窗口显示区域
    private Rect m_WindowRect = new Rect(0, 20, Screen.width, Screen.height-20);
    //窗口滚动区域
    private Vector2 m_scrollPositionText = Vector2.zero;
    //字体大小
    private int fontSize = 30;
    GUISkin skin;
    void OnGUI()
    {
        if (GUI.Button(new Rect(Screen.width-90, 0, 30, 30), "O"))
        {
            m_IsVisible = !m_IsVisible;
        }
        if (!m_IsVisible)
        {
            return;
        }
        m_WindowRect = GUILayout.Window(0, m_WindowRect, ConsoleWindow, "Console");
    }

    //日志窗口
    void ConsoleWindow(int windowID)
    {
        GUILayout.BeginHorizontal();
        skin.button.fontSize = fontSize;
        skin.textArea.fontSize = fontSize;      
        if (GUILayout.Button("Clear", skin.button, GUILayout.MaxWidth(120), GUILayout.MaxHeight(35)))
        {
            m_logAll.Clear();
        }      
        if (GUILayout.Button("Log", skin.button, GUILayout.MaxWidth(120), GUILayout.MaxHeight(35)))
        {
            if (curLog == m_logLog)
                curLog = m_logAll;
            else
                curLog = m_logLog;
        }
        if (GUILayout.Button("Warning", skin.button, GUILayout.MaxWidth(120), GUILayout.MaxHeight(35)))
        {
            if (curLog == m_logWarning)
                curLog = m_logAll;
            else
                curLog = m_logWarning;
        }
        if (GUILayout.Button("Error", skin.button, GUILayout.MaxWidth(120), GUILayout.MaxHeight(35)))
        {
            if (curLog == m_logError)
                curLog = m_logAll;
            else
                curLog = m_logError;
        }
        GUILayout.EndHorizontal();
        m_scrollPositionText = GUILayout.BeginScrollView(m_scrollPositionText, skin.horizontalScrollbar, skin.verticalScrollbar);
        for (int i = 0; i < curLog.Count; i++)
        {
        
            Color currentColor = GUI.contentColor;
            switch (curLog[i].type)
            {
                case LogType.Warning:
                    GUI.contentColor = Color.white;
                    break;
                case LogType.Assert:
                    GUI.contentColor = Color.black;
                    break;
                case LogType.Log:
                    GUI.contentColor = Color.green;
                    break;
                case LogType.Error:
                case LogType.Exception:
                    GUI.contentColor = Color.red;
                    break;
            }
            if (GUILayout.Button(curLog[i].condition, skin.textArea))
            {
                curLog[i].isOpen = !curLog[i].isOpen;;
            }
            if (curLog[i].isOpen) {
                GUILayout.Label(curLog[i].stackTrace, skin.box);
            }
            
            GUI.contentColor = currentColor;
        }

       
        GUILayout.EndScrollView();
    }

    public class LogInfo
    {
        public LogType type;
        public string condition;
        public string stackTrace;
        public string nowDate;
        public bool isOpen;

        public LogInfo(LogType type, string condition, string stackTrace, string nowDate)
        {
            this.type = type;
            this.condition = condition;
            this.stackTrace = stackTrace;
            this.nowDate = nowDate;
            isOpen = false;
        }
        public override string ToString()
        {
            return nowDate + "   " + type.ToString() + "：" + condition + "    ==>：" + stackTrace;
        }
    }
}
