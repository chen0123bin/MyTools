﻿using UnityEngine;
using System.Collections;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Generic;
using System.IO;
using System;


public class LWLogClient
{
    private static LWLogClient mInstance = null;

    private Socket mSocketSend = null;

    private Queue<string> mQueueSend = new Queue<string>();

    public static LWLogClient GetSingleton()
    {
        if (mInstance == null)
        {
            mInstance = new LWLogClient();
        }
        return mInstance;
    }

    public void Connect(string varIp, int varPort)
    {
        if (mSocketSend == null)
        {
            Thread t1;
            t1 = new Thread(StartServer);
            t1.Start(new object[] { varIp, varPort });
        }
    }

    private void StartServer(object param)
    {
        object[] param1 = (object[])param;
        mSocketSend = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        mSocketSend.Connect(param1[0].ToString(), (int)param1[1]);
        while (true)
        {
            if (mQueueSend.Count > 0)
            {
                string tmpContent = mQueueSend.Dequeue();
                byte[] tmpData = System.Text.Encoding.Default.GetBytes(tmpContent);
                mSocketSend.Send(tmpData);
            }
            Thread.Sleep(1);
        }
    }

        
    public void Send(string varContent)
    {
        mQueueSend.Enqueue(varContent);
    }

    public void DisConnect()
    {
        if (mSocketSend != null)
        {
            mSocketSend.Close();
        }
    }
}



